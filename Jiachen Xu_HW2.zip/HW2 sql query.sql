##problem6
select distinct title, count(titleauthor.au_id) as "Number of Authors"
from titles, authors, titleauthor 
where titles.title_id = titleauthor.title_id and titleauthor.au_id = authors.au_id
group by title
having count(titleauthor.au_id) >1

##problem7
select titleauthor.au_id as Author_id,
authors.au_fname as Firstname, 
authors.au_lname as Lastname,
count(titleauthor.au_id) as "total titles"
from titleauthor
join authors on 
titleauthor.au_id = authors.au_id
group by authors.au_fname,authors.au_lname,titleauthor.au_id
having count(titleauthor.au_id)>1
order by "total titles" desc

##problem8
SELECT pub_name
FROM publishers
WHERE publishers.pub_id  NOT IN (SELECT titles.pub_id FROM titles)